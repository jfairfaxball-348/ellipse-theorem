Noncrossing Two-Nearest-Predecessor Orders on Nearly Circular Ellipses
John Fairfax-Ball — LaTeX source package (22 October 2026)

All files are in the ZIP root (no subdirectories), as recommended
for Elsevier Editorial Manager. Upload this ZIP as LaTeX source files.
For initial review, upload the separately supplied paper/main.pdf as
the Manuscript if the journal's submission interface allows PDF.

To compile: extract all ZIP contents in one folder, then run:
  latexmk -pdf -interaction=nonstopmode -halt-on-error ellipse-theorem.tex

Requirements: TeX Live with TikZ, AMS packages, natbib, hyperref,
microtype, lmodern, and standard LaTeX extras. The bibliography
is embedded in ellipse-theorem.tex; references.bib is supplied
for convenient future conversion and is not required by latexmk.
The five .tikz files are necessary and must remain beside the .tex.
No 'elsarticle.cls' is bundled; this is a standards-based initial
manuscript in the original article class, not a journal typeset proof.
